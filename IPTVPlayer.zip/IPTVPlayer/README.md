# IPTV Player (Android)

Kotlin + Jetpack Compose + Media3 (ExoPlayer).

## Derleme
1. Android Studio → File → Open → bu klasör (IPTVPlayer)
2. Gradle senkronizasyonunun bitmesini bekle
3. Telefonu USB hata ayıklama açık bağla → Run ▶
   APK için: Build → Build App Bundle(s) / APK(s) → Build APK(s)

## Özellikler
- M3U linki veya Xtream (sunucu/kullanıcı/şifre) ile liste ekleme, birden fazla liste
- Listeler önbelleğe alınır; yenile tuşu ile tekrar indirilir
- Kategori çipleri, arama, favoriler, kanal logoları
- HLS (m3u8), MPEG-TS, DASH oynatma; uzantısız linklerde otomatik HLS denemesi
- #EXTVLCOPT ve "url|User-Agent=..." başlık desteği
- Tam ekran yatay oynatıcı, önceki/sonraki tuşlarıyla kanal değiştirme, TV tarzı kanal göstergesi
- Canlı TS yayını koparsa otomatik yeniden bağlanma

## Dosyalar
- data/M3uParser.kt — liste ayrıştırıcı
- data/PlaylistRepository.kt — indirme, önbellek, listeler, favoriler
- ui/ — Compose ekranları
- PlayerActivity.kt — oynatıcı
