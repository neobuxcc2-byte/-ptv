# Proje için özel kural yok
