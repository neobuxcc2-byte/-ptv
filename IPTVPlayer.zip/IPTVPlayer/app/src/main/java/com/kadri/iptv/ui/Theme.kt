package com.kadri.iptv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Gece yayını paleti: lacivert mürekkep zemin, kanal göstergesi amber'i
private val Ink = Color(0xFF0D1420)
private val TextHigh = Color(0xFFE4EAF4)
private val TextMuted = Color(0xFF8A98B0)
private val Amber = Color(0xFFF2B544)
private val OnAmber = Color(0xFF241A00)

private val Colors = darkColorScheme(
    primary = Amber,
    onPrimary = OnAmber,
    primaryContainer = Amber,
    onPrimaryContainer = OnAmber,
    secondary = Amber,
    onSecondary = OnAmber,
    secondaryContainer = Color(0xFF3A2F14),
    onSecondaryContainer = Color(0xFFFFD98A),
    background = Ink,
    onBackground = TextHigh,
    surface = Ink,
    onSurface = TextHigh,
    surfaceVariant = Color(0xFF1B2638),
    onSurfaceVariant = TextMuted,
    surfaceTint = Ink,
    surfaceContainerLowest = Color(0xFF0A101A),
    surfaceContainerLow = Color(0xFF111A28),
    surfaceContainer = Color(0xFF151F30),
    surfaceContainerHigh = Color(0xFF1A2537),
    surfaceContainerHighest = Color(0xFF1F2B40),
    outline = Color(0xFF34435C),
    outlineVariant = Color(0xFF243149),
)

@Composable
fun IptvTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
