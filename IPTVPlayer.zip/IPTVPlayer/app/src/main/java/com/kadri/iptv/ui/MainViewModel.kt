package com.kadri.iptv.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kadri.iptv.data.Channel
import com.kadri.iptv.data.Playlist
import com.kadri.iptv.data.PlaylistRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = PlaylistRepository(app)
    private var loadJob: Job? = null

    var playlists by mutableStateOf(repo.getPlaylists())
        private set
    var currentPlaylist by mutableStateOf<Playlist?>(null)
        private set
    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var groups by mutableStateOf<List<String>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var favorites by mutableStateOf(repo.getFavorites())
        private set

    fun addPlaylist(name: String, url: String) {
        val p = repo.addPlaylist(name, url)
        playlists = repo.getPlaylists()
        openPlaylist(p)
    }

    fun deletePlaylist(p: Playlist) {
        repo.deletePlaylist(p.id)
        playlists = repo.getPlaylists()
    }

    fun openPlaylist(p: Playlist, forceRefresh: Boolean = false) {
        loadJob?.cancel()
        currentPlaylist = p
        if (!forceRefresh) {
            channels = emptyList()
            groups = emptyList()
        }
        error = null
        loading = true
        loadJob = viewModelScope.launch {
            try {
                val list = repo.loadChannels(p, forceRefresh)
                val grp = withContext(Dispatchers.Default) { list.map { it.group }.distinct() }
                channels = list
                groups = grp
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = friendlyError(e)
            } finally {
                if (isActive) loading = false
            }
        }
    }

    fun closePlaylist() {
        loadJob?.cancel()
        currentPlaylist = null
        channels = emptyList()
        groups = emptyList()
        error = null
        loading = false
    }

    fun toggleFavorite(c: Channel) {
        favorites = if (c.url in favorites) favorites - c.url else favorites + c.url
        repo.setFavorites(favorites)
    }
}

private fun friendlyError(e: Exception): String = when (e) {
    is UnknownHostException -> "Sunucu bulunamadı. Linki ve internet bağlantını kontrol et."
    is ConnectException -> "Sunucuya bağlanılamadı."
    is SocketTimeoutException -> "Sunucu zamanında yanıt vermedi."
    is MalformedURLException -> "Link geçersiz görünüyor."
    is SSLException -> "Güvenli bağlantı kurulamadı (SSL)."
    else -> e.message ?: e.javaClass.simpleName
}
