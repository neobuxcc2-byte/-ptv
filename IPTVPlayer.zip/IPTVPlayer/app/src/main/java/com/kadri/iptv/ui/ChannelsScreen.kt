package com.kadri.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.kadri.iptv.data.Channel
import com.kadri.iptv.data.Playlist

private const val ALL = "\u0000all"
private const val FAVS = "\u0000fav"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelsScreen(vm: MainViewModel, playlist: Playlist, onPlay: (List<Channel>, Int) -> Unit) {
    var query by rememberSaveable(playlist.id) { mutableStateOf("") }
    var searching by rememberSaveable(playlist.id) { mutableStateOf(false) }
    var selectedGroup by rememberSaveable(playlist.id) { mutableStateOf(ALL) }

    val channels = vm.channels
    val favorites = vm.favorites
    val error = vm.error
    val loading = vm.loading

    val filtered = remember(channels, favorites, selectedGroup, query) {
        val q = query.trim()
        channels.filter { c ->
            val inGroup = when (selectedGroup) {
                ALL -> true
                FAVS -> c.url in favorites
                else -> c.group == selectedGroup
            }
            inGroup && (q.isEmpty() || c.name.contains(q, ignoreCase = true))
        }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(selectedGroup, query) { listState.scrollToItem(0) }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(error) {
        // Yenileme başarısız olursa eski liste kalır, hata alttan gösterilir
        if (error != null && channels.isNotEmpty()) snackbar.showSnackbar(error)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { vm.closePlaylist() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                title = {
                    Column {
                        Text(playlist.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (channels.isNotEmpty()) {
                            Text(
                                "${channels.size} kanal",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        searching = !searching
                        if (!searching) query = ""
                    }) { Icon(Icons.Default.Search, contentDescription = "Ara") }
                    IconButton(
                        onClick = { vm.openPlaylist(playlist, forceRefresh = true) },
                        enabled = !loading,
                    ) { Icon(Icons.Default.Refresh, contentDescription = "Listeyi yenile") }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (loading && channels.isNotEmpty()) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            when {
                loading && channels.isEmpty() -> CenterMessage {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(16.dp))
                    Text("Liste indiriliyor…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                error != null && channels.isEmpty() -> CenterMessage {
                    Text("Liste açılamadı", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(error, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { vm.openPlaylist(playlist, forceRefresh = true) }) { Text("Tekrar dene") }
                }

                else -> {
                    if (searching) SearchField(query) { query = it }
                    GroupBar(vm.groups, selectedGroup) { selectedGroup = it }
                    if (filtered.isEmpty()) {
                        CenterMessage {
                            Text(
                                if (selectedGroup == FAVS && query.isBlank()) "Kalbe dokunduğun kanallar burada toplanır."
                                else "Eşleşen kanal yok.",
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 16.dp),
                        ) {
                            itemsIndexed(filtered) { i, c ->
                                ChannelRow(
                                    c = c,
                                    isFav = c.url in favorites,
                                    onClick = { onPlay(filtered, i) },
                                    onFav = { vm.toggleFavorite(c) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CenterMessage(content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    val focus = remember { FocusRequester() }
    OutlinedTextField(
        value = query,
        onValueChange = onChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .focusRequester(focus),
        placeholder = { Text("Kanal adı") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Temizle")
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
    )
    LaunchedEffect(Unit) { focus.requestFocus() }
}

@Composable
private fun GroupBar(groups: List<String>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { GroupChip("Tümü", selected == ALL) { onSelect(ALL) } }
        item { GroupChip("Favoriler", selected == FAVS) { onSelect(FAVS) } }
        items(groups) { g -> GroupChip(g, selected == g) { onSelect(g) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GroupChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label, maxLines = 1) })
}

@Composable
private fun ChannelRow(c: Channel, isFav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            c.number.toString(),
            modifier = Modifier.width(40.dp),
            textAlign = TextAlign.End,
            style = MaterialTheme.typography.labelLarge.copy(fontFeatureSettings = "tnum"),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
        )
        Spacer(Modifier.width(12.dp))
        ChannelLogo(c)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                c.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                c.group,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = onFav) {
            Icon(
                if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFav) "Favorilerden çıkar" else "Favorilere ekle",
                tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ChannelLogo(c: Channel) {
    var failed by remember(c.logo) { mutableStateOf(c.logo == null) }
    Box(
        Modifier
            .size(width = 64.dp, height = 44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (failed) {
            Text(
                c.name.trim().take(2).uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            AsyncImage(
                model = c.logo,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(4.dp),
                onError = { failed = true },
            )
        }
    }
}
