package com.kadri.iptv.data

/** Birçok IPTV sunucusu ExoPlayer'ın varsayılan UA'sını reddediyor; VLC gibi görünmek en uyumlusu. */
const val DEFAULT_USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20"

data class Playlist(
    val id: String,
    val name: String,
    val url: String,
    val addedAt: Long,
)

data class Channel(
    val number: Int,
    val name: String,
    val url: String,
    val logo: String?,
    val group: String,
    val userAgent: String?,
    val referrer: String?,
)

/** Oynatıcıya kanal listesini taşır (Intent'e on binlerce kanal sığmaz). */
object PlaybackQueue {
    @Volatile
    var channels: List<Channel> = emptyList()
}
