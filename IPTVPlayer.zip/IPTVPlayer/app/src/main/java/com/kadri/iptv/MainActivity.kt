package com.kadri.iptv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.kadri.iptv.data.Channel
import com.kadri.iptv.data.PlaybackQueue
import com.kadri.iptv.ui.ChannelsScreen
import com.kadri.iptv.ui.IptvTheme
import com.kadri.iptv.ui.MainViewModel
import com.kadri.iptv.ui.PlaylistsScreen

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent {
            IptvTheme {
                val playlist = vm.currentPlaylist
                if (playlist == null) {
                    PlaylistsScreen(vm)
                } else {
                    BackHandler { vm.closePlaylist() }
                    ChannelsScreen(vm, playlist, onPlay = ::play)
                }
            }
        }
    }

    private fun play(list: List<Channel>, index: Int) {
        PlaybackQueue.channels = list
        startActivity(
            Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_INDEX, index)
        )
    }
}
