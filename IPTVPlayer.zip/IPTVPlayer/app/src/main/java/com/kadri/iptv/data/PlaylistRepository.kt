package com.kadri.iptv.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class PlaylistRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("iptv", Context.MODE_PRIVATE)

    // ---------- Listeler ----------

    fun getPlaylists(): List<Playlist> {
        val arr = JSONArray(prefs.getString(KEY_PLAYLISTS, "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Playlist(o.getString("id"), o.getString("name"), o.getString("url"), o.optLong("addedAt"))
        }
    }

    fun addPlaylist(name: String, url: String): Playlist {
        val p = Playlist(UUID.randomUUID().toString(), name, url, System.currentTimeMillis())
        savePlaylists(getPlaylists() + p)
        return p
    }

    fun deletePlaylist(id: String) {
        savePlaylists(getPlaylists().filterNot { it.id == id })
        cacheFile(id).delete()
    }

    private fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("url", p.url)
                    .put("addedAt", p.addedAt)
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    // ---------- Favoriler ----------

    fun getFavorites(): Set<String> =
        prefs.getStringSet(KEY_FAVORITES, emptySet())?.toSet() ?: emptySet()

    fun setFavorites(set: Set<String>) {
        prefs.edit().putStringSet(KEY_FAVORITES, set).apply()
    }

    // ---------- Kanallar ----------

    /**
     * Önbellekte liste varsa onu açar (hızlı, internetsiz).
     * forceRefresh ya da önbellek yoksa indirir; yeni liste geçerliyse önbelleği değiştirir.
     */
    suspend fun loadChannels(playlist: Playlist, forceRefresh: Boolean): List<Channel> =
        withContext(Dispatchers.IO) {
            val cache = cacheFile(playlist.id)
            if (!forceRefresh && cache.length() > 0) {
                val cached = parse(cache)
                if (cached.isNotEmpty()) return@withContext cached
            }

            val tmp = File(context.cacheDir, "download_${playlist.id}.tmp")
            try {
                download(playlist.url, tmp)
                val fresh = parse(tmp)
                if (fresh.isEmpty()) {
                    throw IOException("Bu linkte kanal bulunamadı. Linkin bir M3U listesi olduğundan emin ol.")
                }
                tmp.copyTo(cache, overwrite = true)
                fresh
            } finally {
                tmp.delete()
            }
        }

    private fun parse(file: File): List<Channel> =
        file.bufferedReader(Charsets.UTF_8).use { M3uParser.parse(it) }

    private fun cacheFile(id: String) = File(context.filesDir, "playlist_$id.m3u")

    private fun download(url: String, target: File) {
        var current = url
        var redirects = 0
        while (true) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", DEFAULT_USER_AGENT)
            }
            try {
                val code = conn.responseCode
                // HttpURLConnection http<->https geçişlerini kendisi takip etmez
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location")
                        ?: throw IOException("Sunucu geçersiz bir yönlendirme döndürdü.")
                    current = URL(URL(current), location).toString()
                    if (++redirects > 5) throw IOException("Çok fazla yönlendirme.")
                    continue
                }
                if (code !in 200..299) {
                    throw IOException("Sunucu hata döndürdü (HTTP $code). Link veya abonelik geçersiz olabilir.")
                }
                conn.inputStream.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                return
            } finally {
                conn.disconnect()
            }
        }
    }

    private companion object {
        const val KEY_PLAYLISTS = "playlists"
        const val KEY_FAVORITES = "favorites"
    }
}
