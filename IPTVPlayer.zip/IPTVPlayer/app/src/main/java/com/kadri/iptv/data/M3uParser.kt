package com.kadri.iptv.data

import java.io.BufferedReader

/**
 * Satır satır M3U okuyucu; büyük (100 bin+ satırlık) listelerde belleği şişirmez.
 * Desteklenenler: #EXTINF nitelikleri (tvg-name, tvg-logo, group-title, tvg-chno),
 * #EXTGRP, #EXTVLCOPT http-user-agent / http-referrer, Kodi tarzı "url|User-Agent=..".
 */
object M3uParser {

    private val attrRegex = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")

    fun parse(reader: BufferedReader): List<Channel> {
        val result = ArrayList<Channel>()
        var title: String? = null
        var attrs: Map<String, String> = emptyMap()
        var extGroup: String? = null
        var ua: String? = null
        var ref: String? = null

        while (true) {
            val line = reader.readLine()?.trim() ?: break
            if (line.isEmpty()) continue

            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val map = HashMap<String, String>()
                    for (m in attrRegex.findAll(line)) {
                        map[m.groupValues[1].lowercase()] = m.groupValues[2].trim()
                    }
                    attrs = map
                    title = extractTitle(line)
                }

                line.startsWith("#EXTVLCOPT", ignoreCase = true) -> {
                    val opt = line.substringAfter(':').trim()
                    val value = opt.substringAfter('=', "").trim()
                    when (opt.substringBefore('=').trim().lowercase()) {
                        "http-user-agent" -> { ua = value }
                        "http-referrer", "http-referer" -> { ref = value }
                    }
                }

                line.startsWith("#EXTGRP", ignoreCase = true) -> {
                    extGroup = line.substringAfter(':').trim()
                }

                line.startsWith("#") -> Unit

                else -> {
                    var url = line
                    var chUa = ua ?: attrs["user-agent"]
                    var chRef = ref ?: attrs["referrer"]

                    val pipe = url.indexOf('|')
                    if (pipe > 0) {
                        for (kv in url.substring(pipe + 1).split('&')) {
                            val v = kv.substringAfter('=', "").trim()
                            when (kv.substringBefore('=').trim().lowercase()) {
                                "user-agent" -> { chUa = v }
                                "referer", "referrer" -> { chRef = v }
                            }
                        }
                        url = url.substring(0, pipe)
                    }

                    val name = title?.takeIf { it.isNotBlank() }
                        ?: attrs["tvg-name"]?.takeIf { it.isNotBlank() }
                        ?: url.substringAfterLast('/')
                    val group = attrs["group-title"]?.takeIf { it.isNotBlank() }
                        ?: extGroup?.takeIf { it.isNotBlank() }
                        ?: "Diğer"
                    val number = attrs["tvg-chno"]?.toIntOrNull() ?: (result.size + 1)

                    result.add(
                        Channel(
                            number = number,
                            name = name,
                            url = url,
                            logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() },
                            group = group,
                            userAgent = chUa,
                            referrer = chRef,
                        )
                    )

                    title = null
                    attrs = emptyMap()
                    extGroup = null
                    ua = null
                    ref = null
                }
            }
        }
        return result
    }

    /** Başlık, tırnak dışındaki ilk virgülden sonra gelir (nitelik içindeki virgüller atlanır). */
    private fun extractTitle(line: String): String {
        var inQuotes = false
        for (i in line.indices) {
            val c = line[i]
            if (c == '"') {
                inQuotes = !inQuotes
            } else if (c == ',' && !inQuotes) {
                return line.substring(i + 1).trim()
            }
        }
        return ""
    }
}
