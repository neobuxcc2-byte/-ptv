package com.kadri.iptv

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.PlayerView
import com.kadri.iptv.data.Channel
import com.kadri.iptv.data.DEFAULT_USER_AGENT
import com.kadri.iptv.data.PlaybackQueue
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_INDEX = "index"
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var osd: LinearLayout
    private lateinit var osdNumber: TextView
    private lateinit var osdName: TextView
    private lateinit var osdGroup: TextView
    private lateinit var statusView: TextView

    private var channels: List<Channel> = emptyList()
    private var index = 0
    private var triedHls = false
    private var reconnects = 0

    private val handler = Handler(Looper.getMainLooper())
    private val hideOsd = Runnable { osd.animate().alpha(0f).setDuration(400).start() }
    private val reconnect = Runnable { playCurrent(forceHls = triedHls) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        channels = PlaybackQueue.channels
        index = savedInstanceState?.getInt(EXTRA_INDEX) ?: intent.getIntExtra(EXTRA_INDEX, 0)
        if (index !in channels.indices) {
            finish()
            return
        }
        setContentView(buildLayout())
        enterFullscreen()
    }

    override fun onStart() {
        super.onStart()
        if (::playerView.isInitialized && player == null) initPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(EXTRA_INDEX, index)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::playerView.isInitialized) enterFullscreen()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_CHANNEL_UP -> { switchChannel(1); true }
        KeyEvent.KEYCODE_CHANNEL_DOWN -> { switchChannel(-1); true }
        else -> super.onKeyDown(keyCode, event)
    }

    // ---------------- Oynatıcı ----------------

    private fun initPlayer() {
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val exo = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(audioAttrs, true)
            .build()
        exo.addListener(playerListener)
        player = exo
        playerView.player = ZappingPlayer(exo)
        playCurrent()
    }

    private fun releasePlayer() {
        handler.removeCallbacksAndMessages(null)
        if (::playerView.isInitialized) playerView.player = null
        player?.release()
        player = null
    }

    private fun playCurrent(forceHls: Boolean = false) {
        val p = player ?: return
        val ch = channels[index]
        triedHls = forceHls
        statusView.visibility = View.GONE

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ch.userAgent ?: DEFAULT_USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        ch.referrer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

        // IPTV'deki çıplak MPEG-TS yayınları için daha toleranslı ayrıştırma
        val extractors = DefaultExtractorsFactory().setTsExtractorFlags(
            DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
        )

        val item = MediaItem.Builder().setUri(ch.url).apply {
            if (forceHls || isHls(ch.url)) setMimeType(MimeTypes.APPLICATION_M3U8)
        }.build()

        val source = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http), extractors)
            .createMediaSource(item)

        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        showOsd(ch)
    }

    private fun switchChannel(delta: Int) {
        if (channels.isEmpty()) return
        index = (index + delta).mod(channels.size)
        reconnects = 0
        handler.removeCallbacks(reconnect)
        playCurrent()
    }

    private fun isHls(url: String) = url.contains("m3u8", ignoreCase = true)

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_READY -> {
                    statusView.visibility = View.GONE
                    reconnects = 0
                }
                Player.STATE_ENDED -> {
                    // Canlı TS yayınlarında sunucu bağlantıyı kesince "bitti" sanılır: yeniden bağlan
                    val p = player ?: return
                    if (p.duration == C.TIME_UNSET && reconnects < 5) {
                        reconnects++
                        handler.postDelayed(reconnect, 1500)
                    }
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            // Uzantısız linkler aslında HLS olabilir: bir kez de HLS olarak dene
            if (!triedHls && !isHls(channels[index].url)) {
                playCurrent(forceHls = true)
                return
            }
            statusView.text = "Yayın açılamadı (${error.errorCodeName}).\nTekrar denemek için dokun ya da kanal değiştir."
            statusView.visibility = View.VISIBLE
        }
    }

    /** Kontrol çubuğundaki önceki/sonraki tuşlarını kanal değiştirmeye bağlar. */
    private inner class ZappingPlayer(player: Player) : ForwardingPlayer(player) {
        override fun getAvailableCommands(): Player.Commands =
            super.getAvailableCommands().buildUpon()
                .add(Player.COMMAND_SEEK_TO_NEXT)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                .build()

        override fun isCommandAvailable(command: Int): Boolean =
            command == Player.COMMAND_SEEK_TO_NEXT ||
                command == Player.COMMAND_SEEK_TO_PREVIOUS ||
                super.isCommandAvailable(command)

        override fun seekToNext() = switchChannel(1)
        override fun seekToPrevious() = switchChannel(-1)
    }

    // ---------------- Ekran ----------------

    private fun showOsd(ch: Channel) {
        osdNumber.text = if (ch.number in 0..999) String.format(Locale.ROOT, "%03d", ch.number) else ch.number.toString()
        osdName.text = ch.name
        osdGroup.text = ch.group
        osd.animate().cancel()
        osd.alpha = 1f
        handler.removeCallbacks(hideOsd)
        handler.postDelayed(hideOsd, 4000)
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun panelBackground() = GradientDrawable().apply {
        setColor(0xCC0D1420.toInt())
        cornerRadius = dp(12).toFloat()
    }

    private fun buildLayout(): FrameLayout {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        playerView = PlayerView(this).apply {
            setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
            setShowFastForwardButton(false)
            setShowRewindButton(false)
            setShowNextButton(true)
            setShowPreviousButton(true)
            setControllerShowTimeoutMs(3000)
            keepScreenOn = true
            setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
                if (visibility == View.VISIBLE && index in channels.indices) showOsd(channels[index])
            })
        }
        root.addView(playerView, FrameLayout.LayoutParams(MATCH, MATCH))

        // TV tarzı kanal göstergesi (OSD)
        osd = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBackground()
            setPadding(dp(18), dp(10), dp(22), dp(14))
            alpha = 0f
        }
        osdNumber = TextView(this).apply {
            setTextColor(0xFFF2B544.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 42f)
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            includeFontPadding = false
        }
        osdName = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            maxLines = 1
            maxWidth = dp(420)
            ellipsize = TextUtils.TruncateAt.END
        }
        osdGroup = TextView(this).apply {
            setTextColor(0xFF8A98B0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 1
            maxWidth = dp(420)
            ellipsize = TextUtils.TruncateAt.END
        }
        osd.addView(osdNumber)
        osd.addView(osdName)
        osd.addView(osdGroup)
        root.addView(
            osd,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
                setMargins(dp(32), dp(24), dp(32), 0)
            },
        )

        statusView = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            background = panelBackground()
            setPadding(dp(20), dp(14), dp(20), dp(14))
            visibility = View.GONE
            setOnClickListener { playCurrent() }
        }
        root.addView(
            statusView,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER).apply {
                setMargins(dp(32), 0, dp(32), 0)
            },
        )
        return root
    }

    private fun enterFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}
